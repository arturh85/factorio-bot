# Factorio - Creative Mode

Based on the old Creative Mode mod created by Y.Petremann, then patched by Pac0master, and also the Test Mode mod created by rk84. By enabling Creative Mode in the game, you can access objects that can generate unlimited items, fluid or energy, or nullify them. Perfect for testing purpose or making initial setup for games.

This is a fork of the Creative Mode (Fix for 0.16) by [Chrisgbk](https://mods.factorio.com/user/chrisgbk).

[Official Forum post](https://forums.factorio.com/viewtopic.php?f=97&t=28005)
