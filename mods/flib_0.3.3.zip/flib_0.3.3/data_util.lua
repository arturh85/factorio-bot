log("FLIB DEPRECATION WARNING: data_util was renamed to data-util in v0.3.1. Please update your require paths. The old path will cease to work in v0.4.0.")
return require("__flib__.data-util")