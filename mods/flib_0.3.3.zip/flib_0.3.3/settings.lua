data:extend{
  {
    type = "int-setting",
    name = "flib-translations-per-tick",
    setting_type = "runtime-global",
    default_value = 50,
    minimum_value = 1
  }
}